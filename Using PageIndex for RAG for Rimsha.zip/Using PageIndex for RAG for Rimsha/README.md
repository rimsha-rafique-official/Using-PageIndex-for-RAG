# Local RAG — Ollama + PageIndex MCP

A clean, layered Python backend that:

- runs **qwen3-vl:2b** locally via **Ollama** (your existing install) — *no cloud LLM inference*
- retrieves documents via the official **PageIndex MCP server** — *no vector DB, no embeddings, no chunking*
- exposes a **FastAPI** API with streaming chat and a built-in **HTML/JS frontend**

> **One honest caveat up front.** PageIndex MCP itself uses PageIndex's hosted document processing (OCR + tree-building). Either you supply an API key (`http_api`) or you use OAuth via PageIndex Chat (`http_chat`). The `local_npx` transport runs an MCP server process on your machine, but it still talks to PageIndex's backend for the heavy lifting — there is no offline PageIndex. The **answer generation** is fully local on your machine; the **document indexing/retrieval** goes through PageIndex MCP as you specified.

---

## Project Layout

```
local-rag-backend/
├── backend/
│   ├── config/                      # all settings in one place
│   │   ├── settings.py
│   │   └── __init__.py
│   ├── models/                      # local LLM layer
│   │   ├── qwen/
│   │   │   └── chat_template.py     # ChatML renderer (raw mode)
│   │   ├── loaders/                 # "is the model installed?"
│   │   │   ├── base.py
│   │   │   └── ollama_loader.py
│   │   ├── inference/               # "talk to the model"
│   │   │   ├── base.py
│   │   │   └── ollama_inference.py  # async + streaming
│   │   └── prompts/                 # prompt builders
│   │       ├── system.py
│   │       └── rag.py
│   ├── mcp/                         # PageIndex MCP integration
│   │   ├── base.py
│   │   ├── pageindex_client.py      # raw MCP transport (stdio + http)
│   │   └── pageindex_service.py     # domain wrapper: submit/tree/retrieve
│   ├── rag/                         # orchestration
│   │   └── pipeline.py
│   ├── api/                         # FastAPI surface
│   │   ├── app.py                   # entrypoint
│   │   ├── deps.py                  # lifespan + DI container
│   │   ├── schemas.py
│   │   ├── routes_documents.py
│   │   ├── routes_chat.py           # /chat + /chat/stream (SSE)
│   │   └── routes_system.py
│   └── utils/
│       └── logging.py
├── frontend/
│   └── index.html                   # served at http://localhost:8000/ui/
├── scripts/
│   ├── run.sh
│   └── smoke_test.py
├── data/pdfs/                       # uploaded PDFs land here
├── requirements.txt
├── .env.example
└── README.md
```

---

## Setup

### 1. Install Ollama and pull the model (you've already done this)

```bash
ollama serve         # start the daemon if not running
ollama pull qwen3-vl:2b
```

### 2. Python dependencies

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure PageIndex MCP

Get an API key from <https://dash.pageindex.ai/api-keys>, then:

```bash
cp .env.example .env
# edit .env and set PAGEINDEX_API_KEY=...
```

> **For local PDF upload:** set `PAGEINDEX_TRANSPORT=local_npx` instead. This requires Node.js ≥ 18 on your machine; the backend will spawn `npx -y @pageindex/mcp` automatically.

### 4. Smoke test before running the server

```bash
python scripts/smoke_test.py
```

You should see:

```
[1/3] Checking Ollama...               OK
[2/3] Generating with local model...   model says: ...
[3/3] Connecting PageIndex MCP...      tools: [...]
ALL CHECKS PASSED
```

### 5. Run the API

```bash
./scripts/run.sh
# or directly:
python -m backend.api.app
```

Open <http://localhost:8000/ui/> for the chat UI, or <http://localhost:8000/docs> for the auto-generated OpenAPI explorer.

---

## API

| Method | Path                    | Purpose                              |
|--------|-------------------------|--------------------------------------|
| GET    | `/system/health`        | Ollama + MCP status, tool list       |
| GET    | `/system/models`        | All installed Ollama models          |
| GET    | `/system/config`        | Active settings                      |
| POST   | `/documents/upload`     | Upload a PDF → returns `doc_id`      |
| GET    | `/documents/`           | List indexed documents               |
| GET    | `/documents/{id}/tree`  | Fetch the PageIndex tree             |
| POST   | `/chat`                 | One-shot answer (non-streaming)      |
| POST   | `/chat/stream`          | Streaming SSE: retrieval → tokens    |

### Example: streaming chat

```bash
curl -N -X POST http://localhost:8000/chat/stream \
  -H "Content-Type: application/json" \
  -d '{
    "doc_id": "<paste from upload response>",
    "question": "What were the key findings in section 3?",
    "params": { "temperature": 0.2 }
  }'
```

You'll receive a stream of `data: {...}\n\n` lines with three event types:

```
data: {"event":"retrieval","sections":[...]}
data: {"event":"token","text":"The"}
data: {"event":"token","text":" key"}
...
data: {"event":"done","stats":{...}}
```

---

## How the pieces fit

```
                  ┌──────────────────────────┐
                  │  FastAPI (api/app.py)    │
                  │  /chat, /documents, ...  │
                  └────────────┬─────────────┘
                               │
                  ┌────────────▼─────────────┐
                  │   RAGPipeline (rag/)     │
                  │   retrieve → prompt →    │
                  │   stream tokens          │
                  └────┬──────────────┬──────┘
                       │              │
        ┌──────────────▼─┐         ┌──▼─────────────────────┐
        │ PageIndexService│        │  OllamaInference       │
        │ (mcp/)          │        │  (models/inference/)   │
        │ submit/tree/    │        │  /api/chat streaming   │
        │ retrieve        │        └──┬─────────────────────┘
        └──────┬──────────┘           │
               │                      │
        ┌──────▼──────────┐    ┌──────▼──────────┐
        │ MCP transport   │    │  Ollama daemon  │
        │ stdio / http    │    │  qwen3-vl:2b    │
        └─────────────────┘    └─────────────────┘
                │
        ┌───────▼──────────┐
        │ PageIndex MCP    │
        │ (cloud or npx)   │
        └──────────────────┘
```

Every layer talks only to the one directly below it. Swapping inference engines (Ollama → llama.cpp) means writing one new class in `models/inference/`. Swapping MCP servers means changing the four tool names in `config/settings.py`.

---

## Configuration cheat-sheet

All in `backend/config/settings.py`, all overridable via env vars in `.env`:

| Variable                | Default                          | What it does                          |
|-------------------------|----------------------------------|---------------------------------------|
| `OLLAMA_BASE_URL`       | `http://localhost:11434`         | Where Ollama is listening             |
| `OLLAMA_MODEL`          | `qwen3-vl:2b`                    | Default model name                    |
| `OLLAMA_KEEP_ALIVE`     | `5m`                             | Keep weights in RAM between requests  |
| `PAGEINDEX_TRANSPORT`   | `http_api`                       | `http_api` / `http_chat` / `local_npx`|
| `PAGEINDEX_API_KEY`     | —                                | Required for `http_api`               |
| `API_HOST`              | `127.0.0.1`                      |                                       |
| `API_PORT`              | `8000`                           |                                       |

Generation params (`temperature`, `top_p`, `top_k`, `num_ctx`, `num_predict`, `repeat_penalty`) live in `GenerationConfig` and can be overridden per-request via the API's `params` field.

---

## Why each layer exists

- **`loaders/`** answers "is the model installed and ready?" — separated so a future llama.cpp / vLLM backend just adds one file.
- **`inference/`** is the runtime call interface (sync + streaming). Pure async; no HTTP-server stuff leaks in.
- **`prompts/`** keeps system messages and prompt assembly as data, not code paths. Edit a template without touching the pipeline.
- **`mcp/`** isolates the MCP wire protocol from the rest of the app. `pageindex_service.py` only exposes `submit_pdf`, `get_tree`, `retrieve` — tool-name changes upstream affect one file.
- **`rag/`** is the orchestrator. Knows nothing about HTTP or MCP transports — only the two service interfaces above it.
- **`api/`** is the only layer that knows about FastAPI, CORS, streaming responses, schemas.

---

## License

MIT for this scaffolding. PageIndex MCP and Ollama have their own licenses.
