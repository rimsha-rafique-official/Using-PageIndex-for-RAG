"""Local model layer."""
