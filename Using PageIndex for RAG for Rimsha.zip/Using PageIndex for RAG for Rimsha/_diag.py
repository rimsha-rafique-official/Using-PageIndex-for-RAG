﻿import asyncio
from dotenv import load_dotenv
load_dotenv(".env")
from backend.mcp import PageIndexService


async def main():
    svc = PageIndexService()
    await svc.start()

    # FULL filename with .pdf suffix
    doc_name = "BC260221473_Assignment%201%E2%80%94508_1.pdf"
    doc_id = "pi-cmp6nqgue01qr01qwhxj5jz79"

    # Inspect the input schemas first so we know the right arg names
    for tool_name in ("get_document", "get_document_structure", "get_page_content", "find_relevant_documents"):
        tool = svc._tools_by_name.get(tool_name)
        if tool:
            print(f"\n--- SCHEMA: {tool_name} ---")
            props = (tool.input_schema or {}).get("properties", {})
            required = (tool.input_schema or {}).get("required", [])
            print(f"  required: {required}")
            for k, v in props.items():
                t = v.get("type", "?")
                desc = v.get("description", "")[:80]
                print(f"  - {k}: {t}  {desc}")

    tests = [
        ("get_document", {"doc_name": doc_name}),
        ("get_document", {"doc_id": doc_id}),
        ("get_document_structure", {"doc_name": doc_name}),
        ("get_page_content", {"doc_name": doc_name, "pages": [1]}),
        ("get_page_content", {"doc_name": doc_name, "page": 1}),
        ("get_page_content", {"doc_id": doc_id, "pages": [1, 2]}),
        ("find_relevant_documents", {"query": "entailment presupposition semantics"}),
    ]

    for tool_name, args in tests:
        print(f"\n========== {tool_name} ==========")
        print(f"args: {args}")
        try:
            r = await svc.client.call_tool(tool_name, args)
            print(f"is_error: {r['is_error']}")
            print(f"raw_text (first 1000 chars):")
            print((r["raw_text"] or "")[:1000])
        except Exception as e:
            print(f"EXCEPTION: {type(e).__name__}: {e}")

    await svc.stop()


asyncio.run(main())